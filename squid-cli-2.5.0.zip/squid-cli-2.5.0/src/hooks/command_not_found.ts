import { Hook } from '@oclif/core';

const hook: Hook<'command_not_found'> = async function () {};

export default hook;
