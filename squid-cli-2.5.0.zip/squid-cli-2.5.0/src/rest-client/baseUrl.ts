import { getConfigField } from '../config';

export const baseUrl = getConfigField('apiUrl');
