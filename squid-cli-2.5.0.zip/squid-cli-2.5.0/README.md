# @subsquid/cli

`sqd(1)` tool for [squid project](https://docs.subsquid.io) management.

## Installation

We recommend installing squid CLI globally:

`npm i -g @subsquid/cli`

For a full `sqd` command reference, see the [Doc page](https://docs.subsquid.io/squid-cli/)
